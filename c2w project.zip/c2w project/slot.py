import tkinter as tk
from tkinter import messagebox

class SlotBookingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Slot Booking")
        self.geometry("1600x1600")
        self.config(bg="lightblue")

        # Add a label to the window
        self.label = tk.Label(self, text="Parking Area", font=("Arial", 50, "bold"), bg="white")
        self.label.pack(pady=20)

        # Add buttons for parking slots
        for i in range(10):
            button = tk.Button(self, text=f"parking NO {i+1}", command=self.book_slot, width=15, height=10)
            button.pack()
            button.place(x=30+150*(i%3), y=150+230*(i//3))

    def book_slot(self):
        messagebox.showinfo("Booking", "Slot booked successfully!")
