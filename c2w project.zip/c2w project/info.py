import tkinter as tk
from tkinter import messagebox, Frame, PhotoImage, Button, Entry
from tkinter import ttk
from PIL import Image, ImageTk
from tkcalendar import DateEntry
from slot import SlotBookingApp

class ParkingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Parking App")
        self.geometry("1800x800")

        self.bg_frame = Frame(self, width=1000, height=800)
        self.bg_frame.pack(fill='both', expand=True)
        self.bg_frame.place(x=-80, y=0)

        original_image = Image.open("bharat.png")
        resized_image = original_image.resize((900, 800))
        self.bg_image = ImageTk.PhotoImage(resized_image)

        self.background_label = tk.Label(self.bg_frame, image=self.bg_image)
        self.background_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.info_frame = Frame(self, bg='#b5e2ff', width=700, height=800)
        self.info_frame.place(x=850, y=0)

        self.label1 = tk.Label(self.info_frame, text="Information page", width=20, height=1, bg='#b5e2ff',
                            font=('Helvetica', 35, 'italic'))
        self.label1.place(x=40, y=70)

        self.label2 = tk.Label(self.info_frame, text='Enter Vehicle Number:', font=('Arial', 20), bg='#b5e2ff', fg='black')
        self.label2.place(x=20, y=190)

        self.label3 = tk.Label(self.info_frame, text='Enter Vehicle Model:', font=('Arial', 20), bg='#b5e2ff', fg='black')
        self.label3.place(x=20, y=290)

        choices = ['Java', 'Python', 'C', 'C++', 'OS']
        self.label4 = tk.Label(self.info_frame, text='Select Batch:', font=('Arial', 20), bg='#b5e2ff', fg='black')
        self.label4.place(x=20, y=400)

        self.combo_box = ttk.Combobox(self.info_frame, values=choices, width=35, height=40)
        self.combo_box.place(x=300, y=400)

        self.label5 = tk.Label(self.info_frame, text='Select Date:', font=('Arial', 20), bg='#b5e2ff', fg='black')
        self.label5.place(x=20, y=500)

        self.label6 = tk.Label(self.info_frame, text='Select Time:', font=('Arial', 20), bg='#b5e2ff', fg='black')
        self.label6.place(x=20, y=600)

        self.entry1 = tk.Entry(self.info_frame, font=('Arial', 15))
        self.entry1.place(x=300, y=200)

        self.entry2 = tk.Entry(self.info_frame, font=('Arial', 15))
        self.entry2.place(x=300, y=295)

        self.entry4 = DateEntry(self.info_frame, width=12, background='darkblue', foreground='white', borderwidth=2,
                                year=2024, font=('Arial', 15))
        self.entry4.place(x=300, y=500)

        self.entry5 = tk.Entry(self.info_frame, font=('Arial', 15))
        self.entry5.place(x=300, y=600)

        self.button = Button(self.info_frame, text='Go to slot booking', bg='cyan3',
                             font=('Arial', 15, 'italic'), bd=5, command=self.go_to_slot_booking)
        self.button.place(x=300, y=700)
        
    def go_to_slot_booking(self):
        self.destroy()
        slot_booking_app = SlotBookingApp()
        slot_booking_app.mainloop()