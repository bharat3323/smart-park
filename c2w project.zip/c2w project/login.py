import tkinter as tk
from tkinter import messagebox, Frame, PhotoImage, Button, Entry
from tkinter import ttk
from PIL import Image, ImageTk
from tkcalendar import DateEntry
from slot import SlotBookingApp
from info import ParkingApp

class Login(tk.Frame):
    def __init__(self, root):
        super().__init__(root)
        self.root = root
        self.root.title("Login Page")
        self.root.geometry("1000x1000")
        self.root.resizable(True, True)
        self.root.state('zoomed')
        
        frame2 = Frame(root, width=800, height=1000, bg='white')
        frame2.place(x=0, y=0)
        
        self.img=PhotoImage(file="parking1.png", width=800, height=2000)
        self.label1 = tk.Label(self.root, image=self.img, bg='white')
        self.label1.place(x=0, y=0)
        
        label2 = tk.Label(self.label1, text="Welcome to ",font=('Arial Black', 30), bg='white', fg='black', justify='center')
        label2.place(x=250, y=20)
        
        label3 = tk.Label(self.label1, text="SmartPark",font=('Cooper Black', 30), bg='white', fg='#1260CC', justify='center')
        label3.place(x=270, y=80)
        
        frame1 = Frame(root, width=500, height=1000, bg='#73A4FF')
        frame1.place(x=800, y=0)
        
        self.logo_image = PhotoImage(file="logo2.png")
        self.logo_label = tk.Label(frame1, image=self.logo_image, bg='#73A4FF')
        self.logo_label.image = self.logo_image
        self.logo_label.place(x=150, y=0)
        
        heading = tk.Label(frame1, text="Login", fg='#ED9121', bg='#73A4FF', font=('Cooper Black', 23, 'bold'))
        heading.place(x=200, y=200)
        
        label1 = tk.Label(frame1, text="Username", font=('ariel', 11), bg='#73A4FF', fg='black')
        label1.place(x=150, y=270)
        
        label2 = tk.Label(frame1, text="Password", font=('ariel', 11), bg='#73A4FF', fg='black')
        label2.place(x=150, y=330)
        
        self.username_entry = Entry(frame1, width=25, fg='black', border=0, bg="#ececec", font=('Microsoft YaHei UI Light', 11))
        self.username_entry.place(x=150, y=290)
        
        self.password_entry = Entry(frame1, width=25, fg='black', border=0, bg="#ececec", font=('Microsoft YaHei UI Light', 11), show="*")
        self.password_entry.place(x=150, y=350)
        
        self.loginbtn=PhotoImage(file="login.png")
        self.signinbtn=PhotoImage(file="signin.png")
        btn1 = tk.Button(frame1, image=self.loginbtn, border=0, cursor='hand2', bg='#73A4FF', command=self.login)
        btn1.place(x=150, y=400)
        
        btn2 = tk.Button(frame1, width=30, pady=7, text="Forgot Password?", font=('ariel', 11), bg='#73A4FF', border=0, fg='blue', cursor='hand2')
        btn2.place(x=120, y=460)
        
        label4 = tk.Label(frame1, text="------------------   or   -----------------", bg='#73A4FF', fg='black')
        label4.place(x=150, y=490)
        
        btn3 = tk.Button(frame1, image=self.signinbtn, border=0, cursor='hand2', bg='#73A4FF')
        btn3.place(x=150, y=520)

    def login(self):
        # Get username and password entered by the user
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Define a dictionary of predefined username-password pairs
        credentials = {
            "bharatbhandari036": "bharat123",
            "login": "123"
            # Add more username-password pairs as needed
        }

        # Check if the entered credentials match any of the predefined pairs
        if username in credentials and credentials[username] == password:
            messagebox.showinfo("Login Successful", "Welcome, " + username + "!")
            self.root.destroy()
            parking_app = ParkingApp()
            parking_app.mainloop()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")